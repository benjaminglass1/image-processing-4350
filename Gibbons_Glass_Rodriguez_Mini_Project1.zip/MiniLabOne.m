function [] = MiniLabOne()
%MINILAB1 is the core function for 
% Dr. Ononye's EENG 4350-34 Image Processing Course
% at UT Tyler HEC
% Due 02/19/2019
%   Each img# function corresponds to each
%   Individual project task.

clf

img1();     
img2();     
img3();
img4();
img5();


end

